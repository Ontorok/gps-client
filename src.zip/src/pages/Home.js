import React from "react";

const Home = () => {
  return (
    <div
      style={{
        textAlign: "center",
      }}
    >
      <h1>Welcome to GPS</h1>
    </div>
  );
};

export default Home;
