import React from "react";
import UsersTable from "../parts/users/UsersTable";

const Users = () => {
  return <UsersTable />;
};

export default Users;
